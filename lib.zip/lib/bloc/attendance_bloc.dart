import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:psm2_attendease/services/ml_service.dart';

part 'attendance_event.dart';
part 'attendance_state.dart';

class AttendanceBloc extends Bloc<AttendanceEvent, AttendanceState> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String userId;
  final MLService _mlService = MLService();

  AttendanceBloc(this.userId) : super(AttendanceInitial()) {
    on<LoadAttendance>(_onLoadAttendance);
    on<UpdateAttendanceStatus>(_onUpdateAttendanceStatus);
    on<ScanFaceForAttendance>(_onScanFaceForAttendance);
    _mlService.initialize();
  }

  Future<void> _onLoadAttendance(
      LoadAttendance event, Emitter<AttendanceState> emit) async {
    try {
      DocumentSnapshot userDoc =
          await _firestore.collection('users').doc(userId).get();
      Map<String, dynamic> weeklySchedule = userDoc['weeklySchedule'];
      emit(AttendanceLoaded(weeklySchedule));
    } catch (e) {
      emit(AttendanceError("Failed to load attendance data"));
    }
  }

  void _onUpdateAttendanceStatus(
      UpdateAttendanceStatus event, Emitter<AttendanceState> emit) {
    if (state is AttendanceLoaded) {
      final currentState = state as AttendanceLoaded;
      final updatedSchedule =
          Map<String, dynamic>.from(currentState.weeklySchedule);

      List<dynamic> updatedClasses =
          List<dynamic>.from(updatedSchedule[event.day] ?? []);
      updatedClasses = updatedClasses.map((classInfo) {
        if (classInfo['subject'] == event.subject) {
          return {...classInfo, 'status': event.status};
        }
        return classInfo;
      }).toList();

      updatedSchedule[event.day] = updatedClasses;

      _firestore
          .collection('users')
          .doc(userId)
          .update({'weeklySchedule': updatedSchedule});

      emit(AttendanceLoaded(updatedSchedule));
    }
  }

  Future<void> _onScanFaceForAttendance(
      ScanFaceForAttendance event, Emitter<AttendanceState> emit) async {
    try {
      final faceDetected = await detectFace(event.imagePath);
      if (faceDetected != null) {
        final imageBytes = await File(event.imagePath).readAsBytes(); // Correct File usage
        _mlService.setCurrentPrediction(imageBytes, faceDetected);
        final referenceData = await fetchProfileData(userId);
        if (await _mlService.matchFace(referenceData)) {
          add(UpdateAttendanceStatus(event.subject, 'present', event.day));
        } else {
          emit(FaceScanFailed("Face does not match."));
        }
      } else {
        emit(FaceScanFailed("No face detected."));
      }
    } catch (e) {
      emit(FaceScanFailed(e.toString()));
    }
  }

  Future<Face?> detectFace(String imagePath) async {
    final inputImage = InputImage.fromFilePath(imagePath);
    final faceDetector = FaceDetector(
      options: FaceDetectorOptions(
        enableContours: false,
        enableLandmarks: true,
      ),
    );
    final List<Face> faces = await faceDetector.processImage(inputImage);
    faceDetector.close();
    return faces.isNotEmpty ? faces.first : null;
  }

  Future<List> fetchProfileData(String userId) async {
    DocumentSnapshot userDoc = await _firestore.collection('users').doc(userId).get();
    if (userDoc.exists && userDoc.data() != null) {
      return List.from(userDoc['faceData']);
    } else {
      throw Exception("User profile data not found.");
    }
  }
}
